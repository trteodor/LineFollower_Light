HI,
I Design this board in Altium Designer, I found all similar objects (holes) and set all via and holes on "thru" - by all layers (in stack manager i don't have any other type of via). 
I belive now all is correct - if it isn't true please show me example where is problem.

Best Regards
Teodor Rosołowski